package com.example.Gestion.Liste.de.Produits.Spring_Boot_React;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionListeDeProduitsSpringBootReactApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionListeDeProduitsSpringBootReactApplication.class, args);
	}

}
