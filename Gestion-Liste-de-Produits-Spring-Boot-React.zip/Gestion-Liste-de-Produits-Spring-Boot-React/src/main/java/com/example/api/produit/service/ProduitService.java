package com.example.api.produit.service;
import com.example.api.produit.modele.Produit;

import java.util.List;
import java.util.Optional;


public interface ProduitService {
    List<Produit> getAllProduits();
    Optional<Produit> getProduitById(Long id);
    Produit saveProduit(Produit produit);
    Produit updateProduit(Produit produit);
    void deleteProduit(Long id);
}