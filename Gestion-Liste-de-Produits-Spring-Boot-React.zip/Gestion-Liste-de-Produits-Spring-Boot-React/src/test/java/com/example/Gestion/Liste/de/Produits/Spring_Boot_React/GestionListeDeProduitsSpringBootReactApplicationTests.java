package com.example.Gestion.Liste.de.Produits.Spring_Boot_React;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionListeDeProduitsSpringBootReactApplicationTests {

	@Test
	void contextLoads() {
	}

}
